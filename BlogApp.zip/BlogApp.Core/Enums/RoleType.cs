﻿namespace BlogApp.Core.Enums
{
    public enum RoleType
    {
        Member = 21,
        BlogRead = 6
    }
}
