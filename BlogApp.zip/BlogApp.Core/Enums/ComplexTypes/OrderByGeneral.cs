﻿namespace BlogApp.Core.Enums.ComplexTypes
{
    public enum OrderByGeneral
    {
        Id = 0,
        Az = 1,
        CreatedDate = 2
    }
}
