﻿namespace BlogApp.Core.DTOs.Concrete
{
    public class EmailSendDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
    }
}
