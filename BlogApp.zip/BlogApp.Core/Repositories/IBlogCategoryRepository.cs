﻿using BlogApp.Core.Entities.Concrete;

namespace BlogApp.Core.Repositories
{
    public interface IBlogCategoryRepository : IGenericRepository<BlogCategory>
    {

    }
}
