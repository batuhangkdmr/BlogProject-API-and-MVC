﻿namespace BlogApp.Core.Response
{
    public class NoContent
    {
    }
}
