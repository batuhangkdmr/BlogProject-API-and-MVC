﻿namespace BlogApp.WEB.Configurations
{
    public class AboutUsPageInfo
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
