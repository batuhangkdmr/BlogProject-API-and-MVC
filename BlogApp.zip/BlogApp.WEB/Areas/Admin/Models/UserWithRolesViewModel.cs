﻿using BlogApp.Core.DTOs.Concrete;
using BlogApp.Core.Entities.Concrete;

namespace BlogApp.WEB.Areas.Admin.Models
{
    public class UserWithRolesViewModel
    {
        public UserListDto UserDto { get; set; }

    }
}
