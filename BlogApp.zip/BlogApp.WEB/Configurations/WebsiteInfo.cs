﻿namespace BlogApp.WEB.Configurations
{
    public class WebsiteInfo
    {
        public string Title { get; set; }
        public string MenuTitle { get; set; }
    }
}