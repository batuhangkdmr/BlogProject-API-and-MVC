﻿namespace BlogApp.Core.Enums.ComplexTypes
{
    public enum ImageType
    {
        User = 0,
        Post = 1
    }
}
