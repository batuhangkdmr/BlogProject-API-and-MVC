﻿namespace BlogApp.Core.Entities.Concrete
{
    public class About
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
