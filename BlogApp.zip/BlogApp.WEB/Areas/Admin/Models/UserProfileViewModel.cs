﻿using BlogApp.Core.DTOs.Concrete;
using BlogApp.Core.Entities.Concrete;

namespace BlogApp.WEB.Areas.Admin.Models
{
    public class UserProfileViewModel
    {
        public UserListDto User { get; set; }
    }
}
