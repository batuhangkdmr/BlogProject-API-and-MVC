﻿namespace BlogApp.Core.Entities.Abstract
{
    public interface IEntity
    {
    }
}
