﻿namespace BlogApp.Core.DTOs.Abstract
{
    public interface IDto
    {
    }
}
