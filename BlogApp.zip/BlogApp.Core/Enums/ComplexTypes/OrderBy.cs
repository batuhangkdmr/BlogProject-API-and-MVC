﻿namespace BlogApp.Core.Enums.ComplexTypes
{
    public enum OrderBy
    {
        Date = 0,
        ViewCount = 1,
        CommentCount = 2
    }
}
