﻿namespace BlogApp.Core.Enums.ComplexTypes
{
    public enum FilterBy
    {
        Category = 0,
        Date = 1,
        ViewCount = 2,
        CommentCount = 3
    }
}
